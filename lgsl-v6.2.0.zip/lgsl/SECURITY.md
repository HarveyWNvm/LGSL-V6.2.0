# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| >= 6.1.x | :white_check_mark: |
| < 6.1   | :x:                |

## Reporting a Vulnerability

If you find any vulnerability please send me a [mail](mailto:neon1226@yandex.com). Describing with images or videos is better. 

I will update LGSL as soon as possible.
